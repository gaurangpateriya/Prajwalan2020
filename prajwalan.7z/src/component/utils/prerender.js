const prerender = navigator.userAgent === 'ReactSnap';
export default prerender;
