import React from 'react'
import * as THREE from "three";
import Cube from './cube'
import Intro from './component/intro'
import { theme } from './component/theme';
import './home.css'
import Gcoea from '../../media/gcoeaLogo.png'
import GcoeaSmall from '../../media/gcoeaLogo1.png'
import Praj from '../../media/logoN.png'
import  {  ThemeProvider } from 'styled-components/macro';
import IconButton from '@material-ui/core/IconButton';
import Menu from '@material-ui/icons/Menu';
import Drawer from '../drawer/drawer'
  export default class Home extends React.Component{
  state={
    showDrawer:false
  }
toggleDrawer=()=>{
  this.setState({showDrawer:!this.state.showDrawer})
}
    render() {
    const {showDrawer}=this.state;
        return (
          <div >        
            <Drawer open={showDrawer} toggleDrawer={this.toggleDrawer}/> 
            <div className="cube_c" >
            <Cube/>
            </div>
            <div style={{width:'100%',display:'flex'}}>
              <div style={{display:'flex',flexDirection:'column', margin:"10px"}}>
                <img src={Praj} width="70px"/>
                <IconButton color="primary" aria-label="upload picture" component="span" onClick={this.toggleDrawer}>
                <Menu style={{color:'white'}}/>
              </IconButton>
              </div>
               <ThemeProvider theme={theme.dark}>
                  <Intro show={true}/>
              </ThemeProvider>
              <div style={{maxWidth:'350px',right:0,position:'absolute',padding:'16px'}}>
                <img src={window.innerWidth<'500'?GcoeaSmall: Gcoea} width={window.innerWidth<'500'?"30%": "100%"}/>
              </div> 
            </div>
          </div>
        )
      }
  }